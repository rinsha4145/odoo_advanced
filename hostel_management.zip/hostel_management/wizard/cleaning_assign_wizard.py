from odoo import fields, models

class CleaningAssignWizard(models.TransientModel):
    _name = 'cleaning.assign.wizard'
    _description = 'Cleaning Assign Wizard'

    room_id = fields.Many2one('hostel.room', string='Room')
    employee_id = fields.Many2one('hr.employee', string='Cleaning Staff')
    cleaning_request_id = fields.Many2one('room.cleaning', string='Cleaning Request')

    def action_cleaning_assign(self):
        """ASSIGN THE CLEANING TO A EMPLOYEE"""
        self.cleaning_request_id.write({'employee_id': self.employee_id.id,
                                        'state': "assigned"})
        return {'type': 'ir.actions.act_window_close'}
