from odoo import fields, models


class RoomAllocationWizard(models.TransientModel):
    _name = 'hostel.room.allocation.wizard'
    _description = 'Room Allocation Wizard'

    student_id = fields.Many2one('hostel.student', string='Students',
                                 store=True)
    room_id = fields.Many2one('hostel.room', string="Room",
                              required=True, domain="[('available_bed','>',0),('is_room_cleaning','=',False)]",
                              store=True)
    assigned_date = fields.Date(string='Assigned Date', default=fields.Date.today(), required=True)

    def action_allot_room(self):
        """ALLOT A ROOM TO A STUDENT"""
        self.student_id.write({'room_id': self.room_id.id,
                               'assigned_date': self.assigned_date})
        self.room_id.write({'is_room_cleaning': False})
        self.room_id.message_post(body=("Student %s has assigned to this room")
                                       % (self.student_id.name),
                                  message_type="comment",
                                  subtype_xmlid="mail.mt_comment")
        return {'type': 'ir.actions.act_window_close'}
