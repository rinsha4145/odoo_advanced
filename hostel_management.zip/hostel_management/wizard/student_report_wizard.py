from odoo import api, fields, models, tools
from odoo.orm.decorators import depends
import io
from odoo.tools import json_default
import json

try:
    from odoo.tools.misc import xlsxwriter
except ImportError:
    import xlsxwriter


class StudentReportWizard(models.TransientModel):
    _name = "student.report.wizard"
    _description = "Student Report Wizard"

    room_ids = fields.Many2many('hostel.room', string="Room")
    student_ids = fields.Many2many('hostel.student', string="Student")
    available_student_ids = fields.Many2many('hostel.student', compute='_compute_available_student_ids',
                                             string="Available Students")

    @api.depends('room_ids', 'room_ids.student_ids')
    def _compute_available_student_ids(self):
        """filtering student_ids based on the room_ids"""
        for record in self:
            if record.room_ids:
                record.available_student_ids = record.room_ids.mapped('student_ids')
            else:
                record.available_student_ids = self.env['hostel.student'].search([])

    @api.onchange('student_ids')
    def _onchange_student_ids(self):
        for record in self:
            if record.student_ids:
                self.room_ids += self.student_ids.room_id

    def print_student_report(self):
        """printing student report"""
        query = """SELECT
        rc.symbol as symbol,
        rs.name AS student_name,
        hr.name AS room_name,
        hs.invoice_status,
        COALESCE(SUM(am.amount_residual_signed), 0) AS pending_amount
        FROM hostel_student AS hs 
        INNER JOIN res_partner AS rs ON rs.id = hs.partner_id
        LEFT JOIN hostel_room AS hr ON hr.id = hs.room_id
        LEFT JOIN account_move AS am ON am.student_id = hs.id AND am.state = 'posted' 
        LEFT JOIN res_currency AS rc ON am.currency_id = rc.id

        WHERE hs.company_id = %s """ % self.env.company.id
        params = []
        if self.room_ids and self.student_ids:
            query += """AND hs.room_id in %s and hs.id in %s """
            params.append(tuple(self.room_ids.ids))
            params.append(tuple(self.student_ids.ids))
        elif self.room_ids:
            query += """AND hs.room_id in %s """
            params.append(tuple(self.room_ids.ids))

        elif self.student_ids:
            query += """AND hs.id in %s """
            params.append(tuple(self.student_ids.ids))
        query += """GROUP BY  rc.symbol,rs.name,hr.name,hs.invoice_status ORDER BY hr.name ASC"""
        self.env.cr.execute(query, params)

        data = self.env.cr.dictfetchall()

        wizard = {
            'student_ids': self.student_ids.mapped('name'),
            'room_ids': self.room_ids.mapped('name')

        }
        return self.env.ref('hostel_management.action_student_report').report_action(self, data={'data': data,
                                                                                                 'wizard': wizard})

    def action_generate_xlsx(self):
        """Generating the report in xlsx format"""
        xlsx_column = ["SL. No.", "Name", "Room", "Invoice Status", "Pending Amount"]
        query = """SELECT
        rs.name AS student_name,
        hr.name AS room_name,
        hs.invoice_status,
        COALESCE(SUM(am.amount_residual_signed), 0) AS pending_amount,
        rc.symbol as symbol
        FROM hostel_student AS hs 
        INNER JOIN res_partner AS rs ON rs.id = hs.partner_id
        LEFT JOIN hostel_room AS hr ON hr.id = hs.room_id
        LEFT JOIN account_move AS am ON am.student_id = hs.id AND am.state = 'posted' 
        LEFT JOIN res_currency AS rc ON am.currency_id = rc.id

        WHERE hs.company_id = %s """ % self.env.company.id
        params = []
        if self.room_ids and self.student_ids:
            query += """AND hs.room_id in %s and hs.id in %s """
            params.append(tuple(self.room_ids.ids))
            params.append(tuple(self.student_ids.ids))
        elif self.room_ids:
            query += """AND hs.room_id in %s """
            params.append(tuple(self.room_ids.ids))

        elif self.student_ids:
            query += """AND hs.id in %s """
            params.append(tuple(self.student_ids.ids))
        query += """GROUP BY  rc.symbol,rs.name,hr.name,hs.invoice_status ORDER BY hr.name ASC"""
        self.env.cr.execute(query, params)
        result = self.env.cr.dictfetchall()
        wizard_filter = {
            'student_ids': self.student_ids.mapped('name'),
            'room_ids': self.room_ids.mapped('name')

        }
        data = {
            'result': result,
            'filter': wizard_filter,
            'columns': xlsx_column,
        }

        return {
            'type': 'ir.actions.report',
            'data': {'model': 'student.report.wizard',
                     'options': json.dumps(data, default=json_default),
                     'output_format': 'xlsx',
                     'report_name': 'Student Report',
                     },
            'report_type': 'xlsx',
        }

    def get_xlsx_report(self, data, response):
        """Get the XLSX report"""
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet('Student Report')

        result = data['result']
        filter = data['filter']
        columns = data['columns']

        head = workbook.add_format(
            {'bold': True, 'font_size': 30, 'align': 'center'})

        no_data = workbook.add_format(
            {'bold': True, 'font_size': 13, 'align': 'center', 'color': "#c9211e"})

        data = workbook.add_format(
            {'font_size': 12, 'align': 'center'})
        data_filter = workbook.add_format(
            {'font_size': 14, 'align': 'center', 'bold': True})

        data_size = workbook.add_format(
            {'font_size': 12, 'bold': True, 'align': 'center', 'bg_color': "#ffdbb6"})

        sheet.set_column('C:G', 20)

        sheet.merge_range('C2:I4', 'Student Report', head)

        current_col = 1
        if len(filter['student_ids']) == 1:
            student = filter.get('student_ids')
            sheet.merge_range('C7:D8', 'Student : %s' % student[0], data_filter)
        if len(filter['room_ids']) == 1:
            room = filter.get('room_ids')
            sheet.merge_range('E7:F8', 'Room : %s' % room[0], data_filter)

        current_row = 12
        if result:
            index = 0
            for col in columns:
                if col == 'Name' and len(filter['student_ids']) == 1:
                    continue
                if col == 'Room' and len(filter['room_ids']) == 1:
                    continue
                current_col += 1
                sheet.write(current_row, current_col, col, data_size)

            for rec in result:
                current_col = 2
                current_row += 1
                index += 1
                sheet.write(current_row, current_col, index, data)
                if len(filter['student_ids']) != 1:
                    current_col += 1
                    sheet.write(current_row, current_col, rec['student_name'], data)
                if len(filter['room_ids']) != 1:
                    current_col += 1
                    sheet.write(current_row, current_col, rec['room_name'], data)
                current_col += 1
                sheet.write(current_row, current_col, rec['invoice_status'], data)
                current_col += 1
                if rec['symbol']:
                    sheet.write(current_row, current_col, f"{rec['pending_amount']} {rec['symbol']}", data)
                else:
                    sheet.write(current_row, current_col, rec['pending_amount'], data)
        else:
            sheet.merge_range('C15:G16', 'No Records', no_data)

        workbook.close()
        output.seek(0)
        response.stream.write(output.read())
        output.close()
