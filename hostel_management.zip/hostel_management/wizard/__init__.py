from . import room_allocation_wizard
from . import room_vacate_wizard
from . import cleaning_assign_wizard
from . import  student_report_wizard