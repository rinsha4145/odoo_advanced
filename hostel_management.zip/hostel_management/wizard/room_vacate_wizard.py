from odoo import fields, models, api


class RoomVacatingWizard(models.TransientModel):
    _name = 'hostel.room.vacate.wizard'
    _description = 'Room Vacating Wizard'

    student_id = fields.Many2one('hostel.student', string='Student')
    vacating_date = fields.Date(string='Vacating Date', default=fields.Date.today())
    # room_id = fields.Many2one('hostel.room', string='Room')
    product_id = fields.Many2one('product.product',
                                 default=lambda self: self.env.ref('hostel_management.product_data_1'))

    def action_room_vacating(self):
        """VACATE THE STUDENT FROM ROOM IF INVOICE NOT CREATED, CREATE IT"""
        self.ensure_one()
        self.student_id.write({'vacating_date': self.vacating_date})
        amount_per_day = self.student_id.room_id.monthly_rent / 30
        date = self.student_id.assigned_date - self.student_id.vacating_date
        used_days = abs(date.days) + 1

        if self.student_id.room_id:
            today = fields.Date.today()
            for student in self.student_id:
                data = self.env['account.move'].search(
                    [('state', 'in', ['posted', 'draft']), ('partner_id', '=', student.partner_id)])
                invoice_exists = False

                for record in data:
                    if record.invoice_date and (
                            record.invoice_date.month == today.month and record.invoice_date.year == today.year) and record.room_id:
                        invoice_exists = True
                if not invoice_exists:
                    self.env['account.move'].create({
                        'partner_id': self.student_id.partner_id.id,
                        'student_id': student.id,
                        'room_id': student.room_id.id,
                        # 'currency_id': self.currency_id.id,
                        'move_type': 'out_invoice',
                        'invoice_date': today,
                        'invoice_date_due': today,
                        # 'account_id': self.,
                        'invoice_line_ids': [(0, 0, {
                            'name': self.product_id.name,
                            # 'origin': self.product_id.id,
                            # 'account_id': self.account_income.id,
                            'price_unit': used_days * amount_per_day,
                            'quantity': 1.0,
                            'discount': 0.0,
                            # 'taxes': 0.0,
                            # 'uom_id': self.product_id.uom_id,
                            'product_id': self.product_id.id,

                        })],

                    })
        room =self.student_id.room_id
        self.student_id.room_id = False
        self.student_id.assigned_date = False

        is_new_request = any(request.state in ['new','assigned'] for request in room.cleaning_ids)

        if not is_new_request:
            if len(room.student_ids) != 0:
                return
            else:
                self.env['room.cleaning'].create({
                    'room_id': room.id,
                })

        return {'type': 'ir.actions.act_window_close'}
