from odoo import fields, models, api


class HostelFacility(models.Model):
    _name = 'hostel.facility'
    _description = 'Hostel facilities'
    _rec_name = 'name'

    name = fields.Char(string='Name',required=True)
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.company.currency_id,
        readonly=True
    )
    monthly_charge = fields.Monetary(string='Monthly Charge',
                                     currency_field='currency_id')
    room_ids = fields.Many2many('hostel.room', string='Room')

    facility_warn_msg_send = fields.Boolean(default=False, compute='is_zero',
                                            readonly=False)
    company_id = fields.Many2one('res.company', string='Company',
                                 default=lambda self: self.env.company)
    room_count = fields.Integer(string="Rooms",
                                compute='compute_room_count',
                                default=0)



    @api.depends('monthly_charge')
    def is_zero(self):
        """CHECKING WHETHER THE MONTHLY CHARGE IS EMPTY"""
        for record in self:
            if record.monthly_charge == 0.0:
                record.facility_warn_msg_send = True
            else:
                record.facility_warn_msg_send = False

    @api.depends('room_ids')
    def compute_room_count(self):
        """CALCULATE THE COUNT OF ROOMS"""
        for record in self:
            record.room_count = len(record.room_ids)

    # @api.model
    # def name_search(self, name='', args=None, operator='ilike', limit=100):
    #     """SEARCH THE FACILITY BY NAME & MONTHLY CHARGE"""
    #     args = args or []
    #     domain = []
    #     if name:
    #         domain = [
    #             '|',
    #             ('name', operator, name),
    #             ('monthly_charge', operator, name),
    #         ]
    #     final_domain = args + domain
    #     facilities = self.search(final_domain, limit=limit)
    #     return [(facility.id, facility.display_name) for facility in facilities]

    def action_get_room_records(self):
        """GET ROOM RECORDS FOR SMART BUTTON"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Rooms',
            'view_mode': 'list,form',
            'res_model': 'hostel.room',
            'domain': [('facility_ids', 'in', self.id)],
            'context': "{'create': False}"
        }
