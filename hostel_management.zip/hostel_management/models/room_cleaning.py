from odoo import fields, models

class RoomCleaning(models.Model):
    _name = 'room.cleaning'
    _description = 'Hostel Cleaning'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'

    room_id = fields.Many2one('hostel.room', string='Room', required=True, domain="[('student_ids','=',False),('is_room_cleaning','=', False)]")
    start_time = fields.Datetime(string='Start Time')
    stop_time = fields.Datetime(string='Stop Time')
    employee_id = fields.Many2one('hr.employee', string='Cleaning Staff')
    state = fields.Selection([('new', 'New'), ('assigned', 'Assigned'), ('started', 'Started'), ('done', 'Done')],
                             string='State',
                             default='new')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id)

    def action_open_cleaning_assign_wizard(self):
        """OPEN CLEANING ASSIGN WIZARD"""
        if self.env.user.has_group('hostel_management.group_warden'):
            return {
                'type': 'ir.actions.act_window',
                'name': 'Assign Employee',
                'res_model': 'cleaning.assign.wizard',
                'view_mode': 'form',
                'target': 'new',
                'context': {'default_cleaning_request_id': self.id},
            }
        else:
            employee = self.env.user.employee_id
            for record in self:
                if record.employee_id:
                    continue
                record.write({'employee_id': employee.id,
                              'state': "assigned"})


    def action_start_cleaning(self):
        """START CLEANING OF THE ROOM"""
        self.start_time = fields.Datetime.now()
        self.state = 'started'

    def action_complete_cleaning(self):
        """COMPLETE CLEANING OF THE ROOM"""
        self.state = 'done'
        self.stop_time = fields.Datetime.now()

    def action_self_cleaning_assign(self):
        """SELF ASSIGN THE CLEANING """

