import datetime
import calendar

from odoo import models, fields, api, _
from datetime import date
from odoo.tools import date_utils

ROOM_STATUS = [
    ('empty', 'Empty'),
    ('partially_allocated', 'Partially Allocated'),
    ('fully_allocated', 'Fully Allocated')
]


class HostelRoom(models.Model):
    _name = 'hostel.room'
    _description = 'Room for allocation for students'
    _inherit = ['mail.thread', 'avatar.mixin']

    name = fields.Char(string='Name', required=True)
    type = fields.Selection(selection=[
        ('single', 'Single'),
        ('double', 'Double'),
    ])
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.company.currency_id,
        readonly=True
    )
    room_rent = fields.Monetary(string='Room Rent',
                                currency_field='currency_id')
    facility_ids = fields.Many2many('hostel.facility',
                                    check_company=True,
                                    string='Facilities',
                                    domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]")
    monthly_rent = fields.Monetary(string='Monthly Rent',
                                   compute='_compute_monthly_rent',
                                   inverse='_inverse_monthly_rent',
                                   currency_field='currency_id', readonly=False)
    bed_count = fields.Integer(string='Bed Count', default=1, required=True)
    display_name = fields.Char(string='Display Name')
    available_bed = fields.Integer(string='Available Bed',
                                   compute='_compute_available_bed', store=True)
    room_number = fields.Char(
        string="Room Number",
        required=True, copy=False, readonly=True,
        default=lambda self: _('New'))
    company_id = fields.Many2one('res.company', string='Company',
                                 default=lambda self: self.env.company)
    state = fields.Selection(
        selection=ROOM_STATUS, string="Status", readonly=True, copy=False,
        index=True, tracking=3, group_expand=True, default='empty',
        compute='_compute_room_state', store=True)
    student_ids = fields.One2many('hostel.student', 'room_id',
                                  string='Students', domain="[('room_id','=',False)]",
                                  readonly=True, copy=False)
    product_id = fields.Many2one('product.product',
                                 default=lambda self: self.env.ref('hostel_management.product_data_1'))
    invoice_count = fields.Integer(string="Invoice",
                                   compute='_compute_invoice_count',
                                   default=0)
    invoice_ids = fields.One2many('account.move', 'room_id')
    pending_amount = fields.Monetary(string='Pending Amount', compute='_compute_pending_amount', store=True)
    cleaning_ids = fields.One2many('room.cleaning', 'room_id', string='Room Cleaning')

    is_room_cleaning = fields.Boolean(string='Room Cleaned', default=False, compute='_compute_is_room_cleaning',
                                      store=True)

    @api.depends('cleaning_ids.state', 'is_room_cleaning')
    def _compute_is_room_cleaning(self):
        """CHECK WHETHER THE ROOM IS CLEANING"""
        # cleaning_ids = self.cleaning_ids
        filtered_cleaning_ids = self.cleaning_ids.filtered(lambda r: r.state == 'started')
        # for record in self.cleaning_ids:
        #     print(record.id,record.state)
        if filtered_cleaning_ids:
            self.is_room_cleaning = True
        else:
            self.is_room_cleaning = False

    @api.depends('bed_count', 'student_ids.room_id', 'student_ids')
    def _compute_available_bed(self):
        """CALCULATE THE AVAILABLE BED COUNT"""
        for room in self:
            allocated = len(room.student_ids)
            room.available_bed = max(room.bed_count - allocated, 0)

    @api.depends('student_ids')
    def _compute_invoice_count(self):
        """CALCULATE THE INVOICE COUNT FOR SMART BUTTON"""
        for record in self:
            record.invoice_count = self.env['account.move'].search_count([('room_id', 'in', self.id)])

    @api.depends('bed_count', 'available_bed')
    def _compute_room_state(self):
        """STATE UPDATE BASED ON BED AVAILABILITY"""
        for room in self:
            if room.available_bed == room.bed_count:
                room.state = 'empty'
            elif room.available_bed == 0:
                room.state = 'fully_allocated'
            else:
                room.state = 'partially_allocated'

    @api.depends('invoice_ids')
    def _compute_pending_amount(self):
        """CALCULATE THE PENDING AMOUNT FOR A ROOM SUMMING UNPAID INVOICE"""
        # for room in self:
        # pending_amount = 0.00
        # for student in room.student_ids:
        # invo = self.invoice_ids
        # fil = invo.filtered(lambda l: l.move_type == 'out_invoice' and l.state == 'posted' and l.payment_state in ['not_paid','partial'] )
        # invoices = self.env['account.move'].search(
        #     [('student_id', '=', student.id), ('move_type', '=', 'out_invoice'), ('state', '=', 'posted'),
        #      ('payment_state', 'in', ['not_paid', 'partial'])])
        # print(invoices)
        # pending_amount = sum(self.invoice_ids.mapped('amount_residual_signed'))
        invoice = self.invoice_ids.filtered(lambda l: l.state == 'posted')
        self.write({'pending_amount': sum(invoice.mapped('amount_residual_signed'))})

    @api.depends('room_rent', 'facility_ids.monthly_charge')
    def _compute_monthly_rent(self):
        """CALCULATE THE TOTAL MONTHLY RENT WITH ADDING THE FACILITY CHARGE + RENT AMOUNT"""
        for room in self:
            room.monthly_rent = room.room_rent
            for record in room.facility_ids:
                room.monthly_rent = room.monthly_rent + record.monthly_charge

    @api.depends('monthly_rent', 'facility_ids.monthly_charge')
    def _inverse_monthly_rent(self):
        """CALCULATE THE ROOM RENT FROM THE MONTHLY CHARGE"""
        for room in self:
            total = 0.00
            for record in room.facility_ids:
                total += record.monthly_charge
            if room.monthly_rent >= total:
                room.room_rent = room.monthly_rent - total

    @api.depends('name')
    def _compute_display_name(self):
        """DISPLAY NAME FOR ROOM"""
        for room in self:
            room.display_name = f"{room.name} - [{room.room_number}] "

    @api.model_create_multi
    def create(self, vals_list):
        """SEQUENCE CREATION FOR ROOM RECORD"""
        for vals in vals_list:
            if vals.get('room_number', 'New') == 'New':
                vals['room_number'] = (self.env['ir.sequence'].
                                       next_by_code('hostel.room') or 'New')
        return super(HostelRoom, self).create(vals_list)

    def action_get_invoice_records(self):
        """GET INVOICE RECORD OF ROOM FOR SMART BUTTON"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Invoices',
            'view_mode': 'list,form',
            'res_model': 'account.move',
            'domain': [('room_id', 'in', self.id), ('move_type', '=', 'out_invoice')],
            'context': {'create': False}
        }

    def action_open_invoice_form(self):
        """CREATE A INVOICE FORM EACH STUDENT IN THE ROOM WHO DON'T HAVE A INVOICE IN THE CURRENT MONTH"""
        self.ensure_one()
        invoices = self.env['account.move']

        today = fields.Date.today()

        messages = []
        warnings = []
        for student in self.student_ids:
            amount_per_day = self.monthly_rent / 30
            if student.assigned_date:
                if student.assigned_date.month == today.month and student.assigned_date.year == today.year:
                    used_days = (today - student.assigned_date).days + 1
                    # print(student.name,1,used_days)
                else:
                    used_days = today.day
                    # print(student.name,2,used_days)
            else:
                used_days = today.day
                # print(student.name, 3, used_days)

            # data = student.partner_id.invoice_ids.filtered(lambda l: l.state in ['posted', 'draft'] )
            print(student.partner_id.invoice_ids)
            data = self.env['account.move'].search(
                [('state', 'in', ['posted', 'draft']), ('partner_id', '=', student.partner_id),
                 ('room_id', '!=', False)])
            print("data", data)
            invoice_exists = False

            for record in data:
                if record.invoice_date and (
                        record.invoice_date.month == today.month and record.invoice_date.year == today.year):
                    invoice_exists = True
                    invoices |= record
                    warnings.append(
                        f'For {student.partner_id.name} Invoice Already Created For The Month {record.invoice_date.strftime('%B')}!')
                    break

            if not invoice_exists:
                # print("used_days", used_days)
                invoice = self.env['account.move'].create({
                    'partner_id': student.partner_id.id,
                    'student_id': student.id,
                    'room_id': student.room_id.id,
                    # 'currency_id': self.currency_id.id,
                    'move_type': 'out_invoice',
                    'invoice_date': today,
                    'invoice_date_due': today,
                    # 'account_id': self.,
                    'invoice_line_ids': [(0, 0, {
                        'name': self.product_id.name,
                        # 'origin': self.product_id.id,
                        # 'account_id': self.account_income.id,
                        'price_unit': used_days * amount_per_day,
                        'quantity': 1.0,
                        'discount': 0.0,
                        # 'taxes': 0.0,
                        # 'uom_id': self.product_id.uom_id,
                        'product_id': self.product_id.id,

                    })],

                })
                messages.append(f'For {student.partner_id.name} Invoice Created!')
                invoices |= invoice
        if messages:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Success!',
                    'message': messages,
                    'type': 'success',
                    'sticky': False,
                }
            }

        if warnings:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Warning!',
                    'message': warnings,
                    'type': 'warning',
                    'sticky': False,

                }
            }

        return {
            'type': 'ir.actions.act_window',
            'name': 'customer invoice',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            # 'res_id': invoice.id,
            'target': 'current',
            'domain': [('id', 'in', invoices.ids)],
            'context': {'_default_move_type': 'out_invoice'}
        }

    def cron_create_monthly_student_invoice(self):
        """AUTO GENERATE OF INVOICE EVERY 1ST MONTH AND SEND THROUGH EMAIL"""
        if date.today().day != 1:
            return
        rooms = self.env['hostel.room'].search([('student_ids', '!=', False)])
        print(rooms)
        for record in rooms:
            for student in record.student_ids:
                # print("name",student.name)
                invoice_create = True
                invoice_exists = self.env['account.move'].search(
                    [('student_id', '=', student.id),
                     ('room_id', '=', record.id)])

                if invoice_exists:
                    # for invoice in invoice_exists:
                    #     invoice_create = True
                    #     print("exist",invoice.student_id.name)
                    #     if invoice.invoice_date and (
                    #             invoice.invoice_date.month == date.today().month and invoice.invoice_date.year == date.today().year):
                    current_month_invoices = invoice_exists.filtered(lambda invoice: invoice.invoice_date and
                                                                                     invoice.invoice_date.month == date.today().month and invoice.invoice_date.year == date.today().year)
                    if current_month_invoices:
                        invoice_create = False

                if invoice_create:
                    invoice = self.env['account.move'].create({
                        'partner_id': student.partner_id.id,
                        'student_id': student.id,
                        'room_id': student.room_id.id,
                        'company_id': student.company_id.id,
                        # 'currency_id': self.currency_id.id,
                        'move_type': 'out_invoice',
                        'invoice_date': date.today(),
                        'invoice_date_due': date.today(),
                        # 'account_id': self.,
                        'invoice_line_ids': [(0, 0, {
                            'name': record.product_id.name,
                            # 'origin': self.product_id.id,
                            # 'account_id': self.account_income.id,
                            'price_unit': record.monthly_rent,
                            'quantity': 1.0,
                            'discount': 0.0,
                            # 'taxes': 0.0,
                            # 'uom_id': self.product_id.uom_id,
                            'product_id': record.product_id.id,

                        })],

                    })
                    invoice.action_post()
