from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import base64


class AccountMove(models.Model):
    _inherit = 'account.move'
    student_id = fields.Many2one('hostel.student', string='Student')
    room_id = fields.Many2one('hostel.room', string='Room')

    def action_post(self):
        """GENERATE A PDF AND SEND THE INVOICE MAIL USING EMAIL TEMPLATE WHEN CONFIRM THE INVOICE"""
        # self.state = 'posted'
        res = super().action_post()
        # _render_qweb_pdf
        for invoice in self:
            template = self.env.ref('hostel_management.email_template_invoice', raise_if_not_found=False)
            attachments = []
            if not template:
                raise ValidationError("Email template not found.")

            if (invoice.room_id):
                invoice_pdf, _ = self.env['ir.actions.report']._render_qweb_pdf(
                    'account.account_invoices', invoice.id,
                )

                invoice_attachment = self.env['ir.attachment'].create({
                    'name': f"{self.name}"
                            f".pdf",
                    'type': 'binary',
                    'datas': base64.b64encode(invoice_pdf),
                    'res_model': 'account.move',
                    'res_id': invoice.id,
                    'mimetype': 'application/pdf',
                })

                attachments.append(invoice_attachment.id)
                email_values = {'email_from': self.env.user.email, 'attachment_ids': [(6, 0, attachments)]}
                template.send_mail(self.id, force_send=True, email_values=email_values)
            # print(invoice_attachment)
            # return {room_id
            #     'type': 'ir.actions.act_window',
            #     'res_model': 'mail.compose.message',
            #     'view_mode': 'form',
            #     'target': 'new',
            #     'context': {
            #         'default_model': 'account.move',
            #         'default_res_ids': [invoice.id],
            #         'default_use_template': bool(template),
            #         'default_template_id': template.id if template else False,
            #         'default_attachment_ids': [(6, 0, attachments)],
            #         'default_invoice_id': self.id if self else False,
            #     }
            # }
            return res
