from odoo import fields, models


class HostelEmployee(models.Model):
    _name = 'hr.employee'
    _description = 'Model to manage hostel employees'



