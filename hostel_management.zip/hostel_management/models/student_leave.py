from datetime import timedelta
from odoo import fields, models, api
from odoo.exceptions import ValidationError


class StudentLeave(models.Model):
    _name = 'student.leave'
    _description = 'Student Leave'
    _inherit = ['mail.thread']
    _rec_name = 'student_id'

    student_id = fields.Many2one('hostel.student', string='Student',
                                 required=True, ondelete='cascade',
                                 domain="[('room_id','!=',False)]")
    date_begin = fields.Date(string='Begin Date', required=True)
    date_end = fields.Date(string='End Date', required=True)
    leave_days = fields.Integer(compute='_compute_leave_days', string="Leave Days")
    status = fields.Selection([('new', 'New'), ('approved', 'Approved'),
                               ('rejected', 'Rejected'), ('cancelled', 'Cancelled')],
                              default='new', tracking=True, copy=False)
    leave_type = fields.Selection(
        [('home visit', 'Home Visit'), ('medical', 'Medical'),
         ('personal', 'Personal'), ('other', 'Other')],
        string="Leave Type", required=True)
    room_id = fields.Many2one('hostel.room', string="Room")
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.company.id,
                                 help='The default company for this user.')

    # payment_id = fields.Many2one('account.payment', string='Payment')

    @api.depends('date_begin', 'date_end')
    def _compute_leave_days(self):
        """CALCULATE THE TOTAL LEAVE COUNT TAKEN BY STUDENT"""
        for record in self:
            if record.date_begin and record.date_end and (record.date_begin <= record.date_end):
                date = record.date_begin - record.date_end
                record.leave_days = abs(date.days) + 1
            else:
                record.leave_days = 0

    @api.depends('student_id', 'date_begin', 'date_end')
    def _compute_display_name(self):
        """DISPLAY NAME FOR STUDENT LEAVE RECORD"""
        for leave in self:
            if not leave.student_id:
                leave.display_name = f"{'New'}"
            else:
                leave.display_name = f"{leave.student_id.name} - [{leave.date_begin} - {leave.date_end}]"

    @api.constrains('date_begin', 'date_end')
    def check_date_begin_end_date(self):
        """CHECK DATE BEGIN > DATE END"""
        today = fields.Date.today()
        for record in self:
            if record.date_begin and record.date_end and (record.date_begin > record.date_end):
                raise ValidationError("The start date cannot be after the end date.")
            else:
                if record.date_begin < today or record.date_end < today:
                    raise ValidationError("You cannot select a past date")

    # @api.constrains('student_id', 'date_begin', 'date_end')
    def check_leave_date_overlapping(self):
        """CHECK THE SAME STUDENT HAVE MULTIPLE LEAVE RECORD IN SAME DATE"""
        for record in self:

            # approved_leaves = self.env['student.leave'].filtered(lambda l: l.student_id == record.student_id.id and l.status == 'approved')
            approved_leaves = self.search([('student_id', '=', record.student_id.id), ('status', '=', 'approved'),('id','!=',record.id)])
            for approved_record in approved_leaves:
                if record.date_begin <= approved_record.date_end and record.date_end >= approved_record.date_begin:
                    raise ValidationError(
                        "%s person already has an approved leave from %s to %s" % (record.student_id.name,record.date_begin,
                                                                                     record.date_end))

    def action_leave_request_approve(self):
        """LEAVE APPROVAL & CREATION OF CLEANING REQUEST IF THE ROOM IS EMPTY"""
        for record in self:
            record.check_leave_date_overlapping()
            room = record.student_id.room_id
            record.status = 'approved'
            if not room:
                continue
            record.room_id = room
            students = room.student_ids
            if not students:
                continue
            current_date = record.date_begin
            end_date = record.date_end
            common_date = False

            while current_date <= end_date:
                room_is_empty = True
                for student in students:
                    student_leave = self.search([('student_id', '=', student.id), ('status', '=', 'approved'),
                                                 ('date_begin', '<=', current_date), ('date_end', '>=', current_date)],
                                                limit=1)
                    if not student_leave:
                        room_is_empty = False
                        break
                if room_is_empty:
                    common_date = current_date
                    break
                current_date += timedelta(days=1)
            if common_date:
                cleaning_request = self.env['room.cleaning'].search(
                    [('room_id', '=', 'room.id'), ('state', 'in', ['new', 'assigned', 'started'])], limit=1)
                if not cleaning_request:
                    self.env['room.cleaning'].create({
                        'room_id': room.id,
                        'start_time': common_date,
                    })
        return True

    def action_leave_request_reject(self):
        """REJECTION BUTTON"""
        for record in self:
            record.status = 'rejected'

    def action_leave_request_cancel(self):
        """CANCEL BUTTON"""
        for record in self:
            record.status = 'cancelled'
