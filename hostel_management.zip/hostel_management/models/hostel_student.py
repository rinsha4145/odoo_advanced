from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError


class HostelStudent(models.Model):
    _name = 'hostel.student'
    _description = 'Student Detail Template'
    _inherit = ['mail.thread']
    _inherits = {'res.partner': 'partner_id'}

    partner_id = fields.Many2one('res.partner', required=True,
                                 ondelete='restrict', bypass_search_access=True,
                                 index=True, string='Related Partner',
                                 help='Partner-related data of the user')
    dob = fields.Date(string='Date of Birth', required=True)
    age = fields.Integer(string='Age', compute='_compute_age_calculation',
                         store=True)
    gender = fields.Selection([
        ('male', 'Male'), ('female', 'Female'), ('other', 'Other')],
        string='Gender')
    room_id = fields.Many2one('hostel.room', string="Allocated Room",
                              domain="[('available_bed','>',0),('is_room_cleaning','=',False)]",
                              copy=False)
    assigned_date = fields.Date(string='Assigned Date')
    vacating_date = fields.Date(string='Vacating Date', readonly=True)
    invoice_status = fields.Selection([('pending', 'Pending'),
                                       ('done', 'Done')], string="Invoice Status",
                                      compute='_compute_update_invoice_status',
                                      default="", readonly=True,store=True )

    monthly_amount = fields.Monetary(string="Monthly Amount", related='room_id.monthly_rent', readonly=True)
    payment_status = fields.Selection([('not paid', 'Not Paid'), ('paid', 'Paid')], default='', readonly=True,
                                      compute='_compute_update_payment_status',store=True )
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.company.id,
                                 help='The default company for this user.')
    student_id = fields.Char(
        string="Student Id",
        required=True, copy=False, readonly=True,
        default=lambda self: _('New'))
    leave_count = fields.Integer(string="Leave Count",
                                 compute="_compute_leave_count")

    # invoice_ids = fields.One2many('account.move', string='Invoices')
    invoice_count = fields.Integer(string="Invoice",
                                   compute='_compute_invoice_count',
                                   default=0)
    invoice_ids = fields.One2many('account.move', 'student_id')

    user_id = fields.Many2one('res.users', 'Portal User', copy=False, readonly=True)

    @api.depends('invoice_ids')
    def _compute_update_payment_status(self):
        """UPDATE OF PAYMENT STATUS FROM INVOICE STATE"""
        filtered_invoices = self.env['account.move'].search(
            [('student_id', 'in', self), ('payment_state', 'in', ['not_paid', 'in_payment', 'partial'])])
        all_Invoice = self.env['account.move'].search(
            [('student_id', 'in', self)])
        for record in self:
            if filtered_invoices:
                record.payment_status = 'not paid'
            elif not filtered_invoices and all_Invoice:
                record.payment_status = "paid"
            else:
                record.payment_status = ""
    @api.depends('invoice_ids')
    def _compute_update_invoice_status(self):
        """UPDATE OF INVOICE STATUS FROM INVOICE STATE"""
        invoice_in_draft = self.invoice_ids.filtered(lambda l:l.state == "draft")
        # print("invoice_in_draft",invoice_in_draft)
        invoice_in_posted = self.invoice_ids.filtered(lambda l:l.state == "posted")
        # draft_invoice = self.env['account.move'].search(
        #     [('student_id', 'in', self), ('state', '=', 'draft')])
        # print("draft_invoice",draft_invoice)
        # post_invoice = self.env['account.move'].search(
        #     [('student_id', 'in', self), ('state', '=', 'posted')])

        for record in self:
            if invoice_in_draft:
                record.invoice_status = 'pending'
            elif invoice_in_posted:
                record.invoice_status = "done"
            else:
                record.invoice_status = ""
            self.write({'invoice_status':record.invoice_status})

    @api.depends('dob')
    def _compute_age_calculation(self):
        """CALCULATE AGE FROM DOB"""
        for record in self:
            if record.dob:
                today = date.today()
                birth = record.dob
                record.age = today.year - birth.year - (
                        (today.month, today.day) < (birth.month, birth.day))
            else:
                record.age = 0

    @api.constrains('age')
    def _check_age(self):
        """CHECK THE AGE IS >= 18"""
        for record in self:
            if record.age < 18:
                raise ValidationError("Student must be 18 years of age or older")

    @api.depends('leave_count')
    def _compute_leave_count(self):
        """COUNT THE LEAVE OF A STUDENT FOR SMART BUTTON"""
        self.leave_count = self.env['student.leave'].search_count([('student_id', 'in', self.id)])

    @api.depends('invoice_ids')
    def _compute_invoice_count(self):
        """COUNT THE INVOICES OF A STUDENT FOR SMART BUTTON"""
        self.invoice_count = len(self.mapped('invoice_ids'))

    @api.model_create_multi
    def create(self, vals_list):
        """SEQUENCE CREATION OF STUDENT RECORD"""
        for vals in vals_list:
            if vals.get('student_id', 'New') == 'New':
                vals['student_id'] = (self.env['ir.sequence'].
                                      next_by_code('hostel.student') or 'New')
        return super(HostelStudent, self).create(vals_list)

    def action_open_room_allot_wizard(self):
        """FOR OPENING THE ALLOT ROOM WIZARD"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Allot Room',
            'res_model': 'hostel.room.allocation.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_student_id': self.id}
        }

    def action_open_room_vacate_wizard(self):
        """FOR OPENING THE VACATE ROOM WIZARD"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Vacate Room',
            'res_model': 'hostel.room.vacate.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_student_id': self.id}
        }

    def action_get_contact_record(self):
        """GET THE CONTACT RECORD OF STUDENT IN SMART BUTTON"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Partner',
            'view_mode': 'form',
            'res_model': 'res.partner',
            'res_id': self.partner_id.id,
            'context': {'create': False}
        }

    def action_get_portal_record(self):
        """GET THE PORTAL RECORD OF STUDENT IN SMART BUTTON"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Users',
            'view_mode': 'form',
            'res_model': 'res.users',
            'res_id': self.user_id.id,
            'target': 'current',
        }

    def action_get_leave_records(self):
        """GET THE LEAVE RECORDS FOR STUDENT IN SMART BUTTON"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Rooms',
            'view_mode': 'list,form',
            'res_model': 'student.leave',
            'domain': [('student_id', 'in', self.id)],
            'context': {'create': False}
        }

    def action_get_invoice_records(self):
        """GET THE INVOICE RECORDS FOR STUDENT IN SMART BUTTON"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Invoices',
            'view_mode': 'list,form',
            'res_model': 'account.move',
            'domain': [('student_id', 'in', self.id)],
            'context': {'create': False}
        }

    def unlink(self):
        """RESTRICT THE DELETION OF STUDENT WHO ALLOTED TO A ROOM"""
        if self.room_id:
            # print(self.room_id)
            raise UserError("The room allotted Student record can't be deleted")
        return super().unlink()

    def action_create_users(self):
        """PORT USER CREATION WHEN STUDENT CREATED"""
        for student in self:
            a = self.filtered(lambda r: r.user_id.login == self.email )
            print(a,"a")
            existing_user = self.env['res.users'].search([('login', '=', student.email)], limit=1)
            print(existing_user,"existing_user")
            if existing_user:
                student.user_id = existing_user.id
                continue
            user = self.env['res.users'].create({
                'name': student.name,
                'login': student.email,
                'email': student.email,
                'partner_id': student.partner_id.id,
            })
            student.user_id = user.id
        return True
