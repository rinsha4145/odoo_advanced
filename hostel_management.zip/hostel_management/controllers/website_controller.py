from odoo import http
from odoo.http import request
from odoo import fields
from datetime import datetime


class WebsiteCustomerForm(http.Controller):
    @http.route('/website/student/form', type='http', auth='public', website=True)
    def customer_form(self, **kw):
        """Render the customer creation form"""
        query = """select *
                   from hostel_room
                   where available_bed > 0"""
        self.env.cr.execute(query)
        result = self.env.cr.dictfetchall()
        if kw:
            return request.render('hostel_management.customer_form_template', {'rooms': result,'default_room':kw['room']})
        else:
            return request.render('hostel_management.customer_form_template', {'rooms': result})


    @http.route('/get/room_datails', type="jsonrpc", auth="public")
    def room_details(self, **kwargs):
        room_id = kwargs.get('room_id')
        print(456789, room_id)
        """Render the customer creation form"""
        if room_id:
            result = self.env['hostel.room'].browse(room_id)
            print(result.facility_ids.mapped('name'))

            return {'facilities': result.facility_ids.mapped('name'),
                    'room_rent': result.room_rent}

    @http.route('/website/student/register', type='http', auth='public', methods=['POST'], website=True, csrf=True)
    def create_customer(self, **post):
        query = """select *
                   from hostel_room
                   where available_bed > 0"""
        self.env.cr.execute(query)
        result = self.env.cr.dictfetchall()

        """Handle form submission and create a new customer"""
        error = {}
        name = post.get('name')
        email = post.get('email')
        phone = post.get('phone')
        dob = post.get('dob')
        room_id = post.get('room_id')
        print(4567, room_id)
        emails = self.env['hostel.student'].sudo().search([]).mapped('email')

        if email in emails:
            error["email_error"] = 'email already exist!'

        today = fields.Date.today()
        birth = datetime.strptime(dob, '%Y-%m-%d').date()
        age = today.year - birth.year - (
                (today.month, today.day) < (birth.month, birth.day))

        if age < 18:
            error['dob_error'] = 'student must be 18 years old!'

        if room_id == 'select a room':
            error['room_error'] = 'select a room!'
        if error:
            return request.render('hostel_management.customer_form_template', {
                'name': name,
                'email': email,
                'phone': phone,
                'dob': dob,
                'room_id': int(room_id),
                'rooms': result,
                **error,
            })

        request.env['hostel.student'].sudo().create({
            'name': name,
            'email': email or False,
            'phone': phone or False,
            'dob': dob or False,
            'room_id': int(room_id) or False,
            'assigned_date': fields.Date.today(),
        })
        student = self.env['hostel.student'].sudo().search([('email', '=', email)])
        room = self.env['hostel.room'].sudo().search([('id', '=', room_id)])
        return request.render('hostel_management.customer_success_template',
                              {'student': student.student_id, 'room': room.room_number})

    @http.route('/get_rooms', auth="public", type='jsonrpc',website=True)
    def get_rooms(self):
        """Get the website categories for the snippet."""
        rooms = request.env[
            'hostel.room'].sudo().search_read(
            [('available_bed', '>', 0)], fields=['name', 'room_rent','id','image_1920'],order='id desc',
    limit=8
        )

        values = {
            'rooms': rooms,
        }
        return values
    @http.route('/room/detail/<int:room_id>', type='http', auth='public', methods=['GET'], website=True, csrf=True)
    def get_room_detail(self,room_id, **post):
        room = request.env[
            'hostel.room'].sudo().browse(room_id)
        attachment = request.env['ir.attachment'].search([('res_model', '=', 'hostel.room'), ('res_id', '=',room.id)])
        return request.render('hostel_management.room_details',{'room': room,'facilities':room.facility_ids.mapped('name'),'attachments':attachment})



