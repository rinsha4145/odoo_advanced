from odoo import models, api
import io
try:
    from odoo.tools.misc import xlsxwriter
except ImportError:
    import xlsxwriter

class StudentReport(models.AbstractModel):
    _name = 'report.hostel_management.report_student_template'
    _description = 'Student Report Template'

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'doc_ids': docids,
            'doc_model': 'hostel.student',
            'data': [t for t in data.get('data', [])],
            'docs': data.get('wizard',{}),
        }