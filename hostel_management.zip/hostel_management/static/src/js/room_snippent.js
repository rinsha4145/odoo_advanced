/** @odoo-module */
import {renderToElement} from "@web/core/utils/render";
import publicWidget from "@web/legacy/js/public/public_widget";
import {rpc} from "@web/core/network/rpc";

publicWidget.registry.get_product_tab = publicWidget.Widget.extend({
    selector: '.room_section',
    async willStart() {
        const result = await rpc('/get_rooms', {});

        if (result) {
            const rooms = result.rooms
            const ChunkSize = 4
            const chunkData = []
            const carousel_id = Math.random();

            for (let i = 0; i < rooms.length; i += ChunkSize) {

                chunkData.push({
                    is_active: i === 0,
                    rooms: rooms.slice(i, i + ChunkSize)
                })

            }

                this.$target.empty().html(renderToElement('hostel_management.room_snippet', {
                    result: chunkData,
                    carousel_id: carousel_id
                }))

        }

    }
});
