import {Interaction} from "@web/public/interaction";
import {registry} from "@web/core/registry";
import {rpc} from "@web/core/network/rpc";

export class RoomSelection extends Interaction {
    static selector = '.room-select-div'

    start() {
        super.start();
        const select = this.el.querySelector('.room_select')
        console.log(select.value)
        if (select && select.value){
            this.inputValue =Number(select.value)
            this.onRoomChange();


        }

    }
    dynamicContent = {
        ".room_select": {
            "t-on-change": (ev) => {
                this.room = {}
                this.inputValue = parseInt(ev.target.value, 10);
                if (this.inputValue != NaN)
                    this.onRoomChange();

            },


        }
    }

    async onRoomChange() {
        const container = this.el.querySelector(".room-select-div");

        try {
            document.getElementById('room-details').innerHTML = "";
            this.room = await rpc(
                "/get/room_datails", {room_id: this.inputValue}
            );
            if (this.room) {
                const details = document.getElementById('room-details')
                const rent = document.createElement('p')
                rent.innerHTML = '<strong>Room Rent :</strong>' + this.room.room_rent
                const facilities = document.createElement('p')
                facilities.innerHTML ='<strong>Facilities :</strong>' + this.room.facilities.join(", ");
                details.append(rent, facilities);
            }

        } catch (error) {
            console.error(error);
        }

    }

}

registry.category("public.interactions").add("hostel_management.room_selection", RoomSelection);