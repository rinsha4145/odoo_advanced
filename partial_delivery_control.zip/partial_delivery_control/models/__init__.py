from . import product_template
from . import stock_picking
from . import res_company
from . import res_config_settings

